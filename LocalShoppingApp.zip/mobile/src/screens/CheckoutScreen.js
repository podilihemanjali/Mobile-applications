import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import API from '../services/api';
import { useCart } from '../context/CartContext';

export default function CheckoutScreen({ navigation }) {
  const [address, setAddress] = useState('');
  const { items, total, clearCart } = useCart();

  const placeOrder = async () => {
    if (!address.trim()) {
      Alert.alert('Address required', 'Please enter delivery address.');
      return;
    }

    try {
      const response = await API.post('/orders', {
        items: items.map(x => ({
          product_id: x.id,
          quantity: x.quantity
        })),
        delivery_address: address
      });

      clearCart();
      Alert.alert(
        'Order placed',
        `Order #${response.data.order_id} placed successfully. Total ₹${response.data.total_amount}`
      );
      navigation.popToTop();
    } catch (e) {
      Alert.alert('Order failed', e.response?.data?.message || 'Please try again.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Checkout</Text>
      <Text>Total: ₹{total.toFixed(2)}</Text>

      <TextInput
        placeholder="Delivery address"
        multiline
        value={address}
        onChangeText={setAddress}
        style={styles.address}
      />

      <Button title="Place Order" onPress={placeOrder} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 15 },
  address: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    minHeight: 100,
    marginVertical: 20,
    textAlignVertical: 'top'
  }
});
