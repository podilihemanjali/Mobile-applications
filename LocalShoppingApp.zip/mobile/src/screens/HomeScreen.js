import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, Button
} from 'react-native';
import API from '../services/api';
import { useCart } from '../context/CartContext';

export default function HomeScreen({ navigation }) {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const { items } = useCart();

  const loadProducts = async (q = '') => {
    try {
      const response = await API.get('/products', { params: { search: q } });
      setProducts(response.data);
    } catch (e) {
      console.log(e.message);
    }
  };

  useEffect(() => { loadProducts(); }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Local Shop</Text>
      <TextInput
        placeholder="Search products..."
        value={search}
        onChangeText={(v) => {
          setSearch(v);
          loadProducts(v);
        }}
        style={styles.search}
      />

      <Button title={`Cart (${items.length})`} onPress={() => navigation.navigate('Cart')} />

      <FlatList
        data={products}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
          >
            <Text style={styles.name}>{item.name}</Text>
            <Text>{item.category}</Text>
            <Text style={styles.price}>₹{item.price}</Text>
            <Text>Stock: {item.stock}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 30, fontWeight: 'bold', marginBottom: 12 },
  search: { borderWidth: 1, borderRadius: 8, padding: 12, marginBottom: 12 },
  card: { borderWidth: 1, borderRadius: 10, padding: 16, marginVertical: 6 },
  name: { fontSize: 19, fontWeight: 'bold' },
  price: { fontSize: 18, marginTop: 6 }
});
