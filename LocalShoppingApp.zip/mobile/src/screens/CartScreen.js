import React from 'react';
import { View, Text, FlatList, Button, StyleSheet } from 'react-native';
import { useCart } from '../context/CartContext';

export default function CartScreen({ navigation }) {
  const { items, removeFromCart, total } = useCart();

  return (
    <View style={styles.container}>
      <FlatList
        data={items}
        keyExtractor={item => String(item.id)}
        ListEmptyComponent={<Text>Your cart is empty.</Text>}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>₹{item.price} × {item.quantity}</Text>
            <Button title="Remove" onPress={() => removeFromCart(item.id)} />
          </View>
        )}
      />

      <Text style={styles.total}>Total: ₹{total.toFixed(2)}</Text>
      <Button
        title="Checkout"
        disabled={!items.length}
        onPress={() => navigation.navigate('Checkout')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  item: { padding: 15, borderWidth: 1, marginBottom: 8, borderRadius: 8 },
  name: { fontSize: 18, fontWeight: 'bold' },
  total: { fontSize: 22, fontWeight: 'bold', marginVertical: 15 }
});
