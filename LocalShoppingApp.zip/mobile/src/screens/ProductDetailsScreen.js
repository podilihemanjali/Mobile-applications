import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useCart } from '../context/CartContext';

export default function ProductDetailsScreen({ route, navigation }) {
  const { product } = route.params;
  const { addToCart } = useCart();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{product.name}</Text>
      <Text>{product.description}</Text>
      <Text style={styles.price}>₹{product.price}</Text>
      <Text>Available stock: {product.stock}</Text>

      <View style={styles.button}>
        <Button
          title="Add to Cart"
          onPress={() => {
            addToCart(product);
            navigation.navigate('Cart');
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 15 },
  price: { fontSize: 24, marginVertical: 15 },
  button: { marginTop: 20 }
});
