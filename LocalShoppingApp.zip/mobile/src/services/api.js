import axios from 'axios';

const API = axios.create({
  // Replace YOUR_COMPUTER_IP with your computer LAN IP.
  // Example: http://192.168.1.10:5000/api
  baseURL: 'http://YOUR_COMPUTER_IP:5000/api'
});

export default API;
