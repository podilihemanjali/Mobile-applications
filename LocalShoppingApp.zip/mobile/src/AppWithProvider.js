// Reference only: CartProvider must wrap App.
import React from 'react';
import App from '../App';
import { CartProvider } from './context/CartContext';

export default function AppWithProvider() {
  return (
    <CartProvider>
      <App />
    </CartProvider>
  );
}
