const express = require('express');
const db = require('../config/db');

const router = express.Router();

router.post('/', async (req, res) => {
  const { user_id = null, items, delivery_address } = req.body;

  if (!Array.isArray(items) || !items.length || !delivery_address) {
    return res.status(400).json({ message: 'Items and delivery address are required' });
  }

  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    let total = 0;
    const checkedItems = [];

    for (const item of items) {
      const [rows] = await connection.execute(
        'SELECT id, price, stock FROM products WHERE id = ? FOR UPDATE',
        [item.product_id]
      );

      if (!rows.length) throw new Error(`Product ${item.product_id} not found`);
      if (rows[0].stock < item.quantity) throw new Error(`Insufficient stock for product ${item.product_id}`);

      total += Number(rows[0].price) * Number(item.quantity);
      checkedItems.push({
        product_id: rows[0].id,
        price: rows[0].price,
        quantity: item.quantity
      });
    }

    const [order] = await connection.execute(
      'INSERT INTO orders (user_id, total_amount, delivery_address) VALUES (?, ?, ?)',
      [user_id, total, delivery_address]
    );

    for (const item of checkedItems) {
      await connection.execute(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
        [order.insertId, item.product_id, item.quantity, item.price]
      );

      await connection.execute(
        'UPDATE products SET stock = stock - ? WHERE id = ?',
        [item.quantity, item.product_id]
      );
    }

    await connection.commit();
    res.status(201).json({
      message: 'Order placed successfully',
      order_id: order.insertId,
      total_amount: total
    });
  } catch (err) {
    await connection.rollback();
    res.status(400).json({ message: err.message });
  } finally {
    connection.release();
  }
});

router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT o.id, o.total_amount, o.delivery_address, o.status, o.created_at,
             p.name, oi.quantity, oi.price
      FROM orders o
      JOIN order_items oi ON o.id = oi.order_id
      JOIN products p ON p.id = oi.product_id
      WHERE o.id = ?
    `, [req.params.id]);

    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Failed to load order' });
  }
});

module.exports = router;
