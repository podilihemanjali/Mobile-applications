# Local Shopping App

A starter full-stack local shopping mobile application.

## Stack
- Mobile: React Native + Expo
- Backend: Node.js + Express
- Database: MySQL

## Features
- Product listing
- Search products
- Product details
- Add to cart
- Cart total
- Place order
- View orders
- REST API
- MySQL database schema and sample data

## Run backend
1. Install Node.js and MySQL.
2. Create the database using `database/local_shopping.sql`.
3. Open `backend/.env` and update MySQL credentials.
4. Run:
   npm install
   npm start

Backend runs on http://localhost:5000

## Run mobile
1. Open `mobile/src/services/api.js`.
2. Replace YOUR_COMPUTER_IP with your computer's LAN IP.
3. In `mobile` run:
   npm install
   npx expo start
4. Scan the QR code using Expo Go.

For an Android phone, do not use localhost in the mobile API URL. Use your computer LAN IP, for example:
http://192.168.1.10:5000/api
