CREATE DATABASE IF NOT EXISTS local_shopping;
USE local_shopping;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    category VARCHAR(80) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT DEFAULT 0,
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    delivery_address VARCHAR(255) NOT NULL,
    status ENUM('PENDING','CONFIRMED','OUT_FOR_DELIVERY','DELIVERED','CANCELLED')
        DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO products (name, description, category, price, stock, image_url) VALUES
('Fresh Tomatoes', 'Locally sourced fresh tomatoes', 'Vegetables', 40.00, 100, ''),
('Potatoes', 'Fresh local potatoes', 'Vegetables', 35.00, 100, ''),
('Bananas', 'Fresh ripe bananas', 'Fruits', 50.00, 80, ''),
('Apples', 'Fresh apples', 'Fruits', 120.00, 60, ''),
('Milk 1L', 'Fresh dairy milk', 'Dairy', 60.00, 50, ''),
('Bread', 'Fresh bakery bread', 'Bakery', 40.00, 70, ''),
('Rice 5kg', 'Premium local rice', 'Groceries', 350.00, 40, ''),
('Cooking Oil 1L', 'Refined cooking oil', 'Groceries', 140.00, 50, '');
